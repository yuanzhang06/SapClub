sap.ui.define([
   "sap/ui/demo/mr/controller/BaseController"
], function (BaseController) {
   "use strict";
   return BaseController.extend("sap.ui.demo.mr.controller.NotFound", {
      onInit: function () {
      }
   });
});